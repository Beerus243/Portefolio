import { createContext } from "react";

let prop: any;

const currentIdContext = createContext(prop);

export default currentIdContext;
